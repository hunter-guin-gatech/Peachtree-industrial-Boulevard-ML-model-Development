import csv
from bisect import bisect

allowed_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
    	f=str(int(line.split('\n')[0])+1000)[1:]
    	allowed_nums.append(f)

thread=1000
Data=[['simNum', 'CI-CO_Dur', 'Base_Dur', 'Solution-1_Dur', 'Predicted-Dur']]
k=0
for simNum in allowed_nums:
    thread+=1
    print(simNum)
    data=[simNum, 0, 0, 0, 0]
    ptypes=['CICO', 'Base', 'Solution-1', 'Trained-Preempt-Run']
 
    fname=f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/20NB_1/CICO/P_NE/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_20_{simNum}.ldp'
    with open(fname) as file:
        for line in file:
            f=line.split('\n')[0].split()
            try:
                ap=int(f[3])
                data[1]+=int(ap!=0)
            except (ValueError, IndexError):
                continue   

    fname=f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/19NB_1/OutputFiles/Final-Preempt-Run/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_20_{simNum}.ldp'
    with open(fname) as file:
        for line in file:
            f=line.split('\n')[0].split()
            try:
                ap=int(f[3])
                data[2]+=int(ap!=0)
            except (ValueError, IndexError):
                continue       

    fname=f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/20NB_1/OutputFiles/Final-Preempt-Run/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_20_{simNum}.ldp'
    with open(fname) as file:
        for line in file:
            f=line.split('\n')[0].split()
            try:
                ap=int(f[3])
                data[3]+=int(ap!=0)
            except (ValueError, IndexError):
                continue  

    fname=f'../model-run-individual/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_20_'+str(thread)[1:]+'.ldp'
    with open(fname) as file:
        for line in file:
            f=line.split('\n')[0].split()
            try:
                ap=int(f[3])
                data[4]+=int(ap!=0)
            except (ValueError, IndexError):
                continue                                                             

    k+=1
    Data.append(data)

with open('2022-08-15_Preempt-Duration-Summary_20NB_Individual.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   