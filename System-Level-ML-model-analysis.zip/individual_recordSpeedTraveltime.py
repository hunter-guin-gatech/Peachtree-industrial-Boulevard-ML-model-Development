import csv
from bisect import bisect

scenarios=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        f=int(line.split('\n')[0])
        scenarios.append(str(f+1000)[1:])

Data=[['simNum', 'No-Preempt_TT', 'No-Preempt_Speed', 'CI-CO_TT', 'CI-CO_Speed', 'Base_TT', 'Base_Speed', 'Solution-1_TT', 'Solution-1_Speed', 'Predicted_TT_1', 'Predicted_Speed_1']]
for simNum in scenarios:
    print(simNum)
    data=[simNum]+[0 for _ in Data[0][1:]]
    ptypes=['NP', 'CICO', 'Base', 'Optimal-Solution-1', 'Trained-Preempt-Run']

    for i in range(4):
        n=0
        X=[0]; T=[0]
        fname='../../../../2022-05-09_PIB-Mainline-Prediction-Model-Development/1_Trajectory_Plots/TrajectoryData/2022-06-08_PIB-RBC-Preempt-Trajectory_'+simNum+'_'+ptypes[i]+'.csv'
        with open(fname) as file:
            for line in file:
                n+=1
                if n>1:
                    f=line.split('\n')[0].split(',')
                    x, t, vtype=float(f[2]), float(f[1]), int(f[3])
                    if x>X[-1] and t>T[-1] and vtype==630:
                        X.append(x); T.append(t)
        j, k=bisect(X, 23942.5), bisect(X, 19367.8)
        Speed=(X[j]-X[k-1])/(T[j]-T[k-1])
        travelTime=(23942.5-19367.8)/Speed
        data[2*i+1]=travelTime
        data[2*i+2]=Speed*0.68181818

    i=4
    m=0
    X=[]; T=[]
    with open(f'./trajdata20NB/2022-08-15_PIB-RBC-Preempt-Trajectory_{simNum}_Individual.csv') as infile:
        for inline in infile:
            m+=1
            if m>1:
                g=inline.split('\n')[0].split(',')
                if int(g[3])==630 and g[0].split('_')[1]=='7':
                    x, t=float(g[2]), float(g[1])
                    X.append(x); T.append(t)

    Speed=(X[-1]-X[0])/len(T[1:])
    travelTime=(23942.5-19367.8)/Speed
    data[2*i+1]=travelTime
    data[2*i+2]=Speed*0.68181818        

    Data.append(data)

with open('2022-08-15_Speed-Traveltime-Summary_20NB_Individual.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   