from matplotlib import pyplot as plt 
import numpy as np 
from scipy.stats import ks_2samp, ttest_ind
import pandas as pd
import seaborn as sns
import os


if not os.path.isdir('./TravelTimePlots'):
    os.makedirs('./TravelTimePlots')  

def BoxplotFormat(list2D):
    maxlen=0
    for l in list2D:
        maxlen=max(maxlen, len(l))
    for i in range(len(list2D)):
        l=len(list2D[i])
        for j in range(l, maxlen):
            list2D[i].append(np.NaN)
    return np.array(list(map(list, zip(*list2D))))

def filterNormalize(list2D, tot_designs):
	list1=[]
	for i in range(3):
		list2=[]
		minm_size=float('Inf')
		maxm_val=float('-Inf')
		for j in range(tot_designs):
			list2.append(sorted(list2D[tot_designs*i+j], reverse=True))
			minm_size=min(minm_size, len(list2D[tot_designs*i+j]))
			if list2[-1]:
				maxm_val=max(maxm_val, list2[-1][0])

		for j in range(len(list2)):
			list2[j]=[k/maxm_val for k in list2[j][:minm_size]]
		list1+=list2

	return list1

designInfo={'CICO': 'CI-CO', 'Base': '(4n + 9) Solution', 'Optimal': "'Extreme' Optimum", 'Ideal': "'Ideal' Optimum", 'Predicted': "Predicted"}         

traveltimeData=[]
for i in range(9):
	data=[]
	for j in range(3):
		for design in designInfo:
			data.append([])
	traveltimeData.append(data)

intersections=[12, 13, 15, 16, 18, 19, 20]

intersectionName=['S.Old Peachtree Rd', 'Highwoods Center', 'Pickneyville Park', 'S.Berkeley Lk Rd', 'N.Berkeley Lk Rd', 'Summit Ridge Pkwy', 'Howell Ferry Rd']

tot_designs=len(designInfo)

columns=list(designInfo.keys())
for i in range(2):
	columns+=[j+'_'+str(i) for j in columns[:tot_designs]]

colors=['lightgreen', 'blue', 'sandybrown', 'cyan', 'pink']*3

for i in range(7):
	for j, design in enumerate(list(designInfo.keys())):
		n=0
		readfile=f'./travelTimeData/TravelTimeDataSideStreets_{intersections[i]}_{design}.csv'
		with open(readfile) as file:
			for line in file:
				n+=1
				f=line.split('\n')[0].split(',')
				if n>1:
					t=float(f[-2]); BIN=int(f[1])
					k=BIN*tot_designs+j
					traveltimeData[i][k].append(t)
					# if i!=5:
					# 	traveltimeData[7][k].append(t)
					# traveltimeData[8][k].append(t)

	if traveltimeData[i]==[[]]*(3*tot_designs):
		continue

	filterData=filterNormalize(traveltimeData[i], tot_designs)

	for l in range(len(filterData)):
		traveltimeData[8][l]+=filterData[l]
		if i!=5:
			traveltimeData[7][l]+=filterData[l]

	Data=BoxplotFormat(traveltimeData[i])
	df = pd.DataFrame(data = Data, columns = columns)
	sns.boxplot(x="variable", y="value", data=pd.melt(df), palette=colors)
	plt.xlabel('Variations with passage of time')
	start=np.median(np.array(range(tot_designs)))
	plt.xticks([start, start+tot_designs,start+2*tot_designs], ['320s after EVP', '320-640s after EVP', '640-960s after EVP'])
	plt.ylabel('Travel Time [s]')
	plt.title(f'Intersection {intersections[i]}: {intersectionName[i]}\nDifferent Experimental Setups: Side Street Travel Time')
	minmax=[np.nanmin(Data), np.nanpercentile(Data, 98)]
	range1=minmax[1]-minmax[0]
	plt.ylim([max(minmax[0]-range1*0.1, 0),  minmax[1]+range1*0.1])
	for l in range(tot_designs):
		plt.plot([], [], label=columns[l], linewidth=10, color=colors[l])
	plt.legend(fontsize=8, ncol=5, bbox_to_anchor=(1, -0.15))
	plt.plot([tot_designs-0.5, tot_designs-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
	plt.plot([tot_designs*2-0.5, tot_designs*2-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
	plt.savefig(f'./TravelTimePlots/SideStreet-BoxPlot_{intersections[i]}.png', bbox_inches='tight', dpi=600) 
	plt.clf()     
	plt.close()  

Data=BoxplotFormat(traveltimeData[7])
df = pd.DataFrame(data = Data, columns = columns)
sns.boxplot(x="variable", y="value", data=pd.melt(df), palette=colors)
plt.xlabel('Variations with passage of time')
start=np.median(np.array(range(tot_designs)))
plt.xticks([start, start+tot_designs,start+2*tot_designs], ['320s after EVP', '320-640s after EVP', '640-960s after EVP'])
plt.ylabel('Travel Time Factor [0, 1]')
plt.title(f'All Intersections along PIB: (without Summit Ridge Pkwy)\nDifferent Experimental Setups: Side Street Travel Time')
minmax=[np.nanmin(Data), np.nanpercentile(Data, 98)]
range1=minmax[1]-minmax[0]
plt.ylim([max(minmax[0]-range1*0.1, 0),  minmax[1]+range1*0.1])
for l in range(tot_designs):
	plt.plot([], [], label=columns[l], linewidth=10, color=colors[l])
plt.legend(fontsize=8, ncol=5, bbox_to_anchor=(1, -0.15))
plt.plot([tot_designs-0.5, tot_designs-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.plot([tot_designs*2-0.5, tot_designs*2-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.savefig(f'./TravelTimePlots/SideStreet-BoxPlot_System-Minus-19.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close() 

Data=BoxplotFormat(traveltimeData[8])
df = pd.DataFrame(data = Data, columns = columns)
sns.boxplot(x="variable", y="value", data=pd.melt(df), palette=colors)
plt.xlabel('Variations with passage of time')
start=np.median(np.array(range(tot_designs)))
plt.xticks([start, start+tot_designs,start+2*tot_designs], ['320s after EVP', '320-640s after EVP', '640-960s after EVP'])
plt.ylabel('Travel Time Factor [0, 1]')
plt.title(f'All Intersections along PIB\nDifferent Experimental Setups: Side Street Travel Time')
minmax=[np.nanmin(Data), np.nanpercentile(Data, 98)]
range1=minmax[1]-minmax[0]
plt.ylim([max(minmax[0]-range1*0.1, 0),  minmax[1]+range1*0.1])
for l in range(tot_designs):
	plt.plot([], [], label=columns[l], linewidth=10, color=colors[l])
plt.legend(fontsize=8, ncol=5, bbox_to_anchor=(1, -0.15))
plt.plot([tot_designs-0.5, tot_designs-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.plot([tot_designs*2-0.5, tot_designs*2-0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.savefig(f'./TravelTimePlots/SideStreet-BoxPlot_System.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close()  	