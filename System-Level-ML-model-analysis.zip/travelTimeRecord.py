from bisect import bisect
import os
import csv

endLimit=[8200, 9400, 11100, 12000, 18600, 19300, 24050]
intersections=[12, 13, 15, 16, 18, 19, 20]

test_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        test_nums.append(int(line.split('\n')[0]))

if not os.path.isdir('./travelTimeData'):
    os.makedirs('./travelTimeData')  

designs=['CICO', 'Base', 'Optimal', 'Ideal', 'Predicted']

designInfo={'CICO': f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/20NB_1/CICO/P_NE/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE', 
            'Base': f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/12NB/model-run/Base/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE',
            'Optimal': f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/20NB/model-run/Final-Preempt-Run/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE',
            'Ideal': f'../../../../2022-05-09_PIB-NB-ERV-Solution-Effort/20NB_1/OutputFiles/Final-Preempt-Run/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE',
            'Predicted': f'../model-run-system/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE'}   


for design in designs:
    Data=[]
    for j in range(7):
        Data.append([['SimNum', 'Time-Bin', 'SideMovementNum', 'TravelTime', 'Delay']])    

    for seed in range(32):

        endLimitTime=[0, 0, 0, 0, 0, 0, 0]
        threadnum=str(1001+seed)[1:]
        simNum=str(1000+test_nums[seed])[1:]
        print('Design:', design, '; Simulation run:', simNum)  

        for j in range(len(intersections)):
            with open(designInfo[design]+f'_{intersections[j]}_{threadnum}.ldp') as file:
                for line in file:
                    f=line.split('\n')[0].split()
                    try:
                        t, isPreempt=float(f[0].split('.0')[0]), int(f[-1])!=0 
                        if isPreempt:
                            endLimitTime[j]=t
                    except (ValueError, IndexError):
                        continue

        with open(designInfo[design]+f'_{threadnum}.rsr') as file:
            for line in file:
                f=line.split(';')
                try:
                    t, No, trav, delay=float(f[0]), int(f[1]),  float(f[4]), float(f[5])
                    if No>=11 and No<=24:
                        j=int((No-11)/2)
                        if t>endLimitTime[j] and t<endLimitTime[j]+960:
                            BIN=int((t-endLimitTime[j])/320)
                            Data[j].append([simNum, BIN, No%2, trav, delay])
                except (ValueError, IndexError):
                    continue

    for j in range(7):
        outfile=f'./travelTimeData/TravelTimeDataSideStreets_{intersections[j]}_{design}.csv'
        with open(outfile, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(Data[j])





