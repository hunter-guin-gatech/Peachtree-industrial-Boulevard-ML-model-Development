from matplotlib import pyplot as plt 
import numpy as np 
from scipy.stats import ks_2samp, ttest_ind
import pandas as pd
import seaborn as sns

def BoxplotFormat(list2D):
    maxlen=0
    for l in list2D:
        maxlen=max(maxlen, len(l))
    for i in range(len(list2D)):
        l=len(list2D[i])
        for j in range(l, maxlen):
            list2D[i].append(np.NaN)
    return np.array(list(map(list, zip(*list2D))))


travelTime=[[], [], [], [], [], []]
speed=[[], [], [], [], [], []]
outfile='2022-08-15_Speed-Traveltime-Summary_20NB_System.csv'
n=0
with open(outfile) as file:
	for line in file:
		n+=1
		if n>1:
			f=line.split('\n')[0].split(',')
			for i in range(6):
				travelTime[i].append(float(f[2*i+1]))
				speed[i].append(float(f[2*i+2]))

columns=['No Preempt', 'CI-CO', '4n+9 Sol.', 'Optimal-Sol.', 'Ideal-Sol.', 'Predicted-Sol']
colors=['orange', 'lawngreen', 'fuchsia', 'teal', 'gray', 'yellow']

# Speed plot

Data=BoxplotFormat(speed)
df = pd.DataFrame(data = Data, columns = columns)
sns.violinplot(x="variable", y="value", data=pd.melt(df), palette=colors, inner="quartile", bw=0.1)
means=[np.nanmean(dat) for dat in Data.T]
plt.plot(columns, means, 'rs') 
plt.xlabel('Experimental Setups')
plt.ylabel('Speed [mph]')
plt.title('System 12NB to 20NB\nDifferent Experimental Setups: Speed Violinplot')
plt.xticks([], [])
minmax=[Data.min(), Data.max()]
range1=minmax[1]-minmax[0]
plt.ylim([minmax[0]-range1*0.2,  minmax[1]+range1*0.2])
for l in range(len(columns)):
	plt.plot([], [], label=columns[l]+'('+str(round(means[l], 1))+')', linewidth=10, color=colors[l])
plt.legend(fontsize=8, ncol=3, bbox_to_anchor=(1, -0.15))
plt.savefig('2022-08-15_20NB-Speed-ViolinPlot_System.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close()  


#Travel time

Data=BoxplotFormat(travelTime)
df = pd.DataFrame(data = Data, columns = columns)
sns.violinplot(x="variable", y="value", data=pd.melt(df), palette=colors, inner="quartile", bw=0.1)
means=[np.nanmean(dat) for dat in Data.T]
plt.plot(columns, means, 'rs')
plt.xlabel('Experimental Setups')
plt.ylabel('TravelTime [s]')
plt.title('System 12NB to 20NB\nDifferent Experimental Setups: Travel-time Violinplot')
plt.xticks([], [])
minmax=[Data.min(), Data.max()]
range1=minmax[1]-minmax[0]
plt.ylim([minmax[0]-range1*0.2,  minmax[1]+range1*0.2])
for l in range(len(columns)):
	plt.plot([], [], label=columns[l]+'('+str(round(means[l], 1))+')', linewidth=10, color=colors[l])
plt.legend(fontsize=8, ncol=3, bbox_to_anchor=(1, -0.15))  
plt.savefig('2022-08-15_20NB-TravelTime-ViolinPlot_System.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close() 