import win32com.client as com
import os
import time
import pathlib
import requests
global Vissim
import ast
import sqlite3
from datetime import datetime
import shutil
import inspect as ins
import sys
import pywintypes
import numpy as np
from bisect import bisect
import csv
import time
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import f1_score
import pickle

convertProportion=lambda p: np.log(0.001) if p<=0 else (np.log(1000) if p>=1 else np.log(p / (1 - p)))

class LogitRegression(MLPRegressor):

    def fit(self, x, p):
        p = np.asarray(p)
        y = np.array(list(map(convertProportion, p)))
        return super().fit(x, y)

    def predict(self, x):
        y = super().predict(x)
        return 1.01 / (np.exp(-y) + 1)

      
preemptTime=[[], [], [], [], [], [], []]
n=0
with open('1_PreemptSummary_12NB-13NB-15NB-16NB-18NB-19NB-20NB.csv') as file:
    for line in file:
        f=line.split('\n')[0].split(',')
        n+=1
        if n>1:
            for i in range(7):
                preemptTime[i].append(float(f[2*i+3])-0.8)

allowed_nums=[]
with open('testing_run-num.txt') as file:
    for line in file:
        allowed_nums.append(int(line.split('\n')[0]))


filename='12NB-NN-EVP-PosExp-0.95.model'

loaded_model = pickle.load(open(filename, 'rb'))                    
                
simtime = 5400
T=35225
fname='2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE'
Vissim = com.Dispatch("Vissim.Vissim.2021")
Filename = os.path.join(os.getcwd(), fname+'.inpx')
Vissim.LoadNet(Filename, False)
Filename = os.path.join(os.getcwd(), fname+'.layx')
Vissim.LoadLayout(Filename)
Vissim.Simulation.SetAttValue('StartDate', '01.09.2019')
Vissim.Simulation.SetAttValue('StartTm', '16:30:00')

simnum=0
for seed in range(1, 6):
    for run in range(0, 160, 5):
        simnum+=1
        if simnum not in allowed_nums[2:]:
            continue
            
        intro_630=T+run*10

        Vissim.Net.Scripts.SetAllAttValues('RunType', 1)
        simRes = Vissim.Simulation.AttValue('SimRes')
        Vissim.Simulation.SetAttValue('SimPeriod', simtime)
        Vissim.Simulation.SetAttValue('UseMaxSimSpeed', True)
        Vissim.Simulation.SetAttValue('RandSeed', seed)
        Vissim.Graphics.CurrentNetworkWindow.SetAttValue("QuickMode",1) 

        flag=[0, 0, 0, 0, 0, 0, 0]
        ERV_links=[81, 638, 639, 640, 641, 642, 643]
        sig_location=[8091.5, 9310, 10971.5, 11913.5, 18503.5, 19212, 23940]
        det10=[-1 for _ in range(160)]
        det12=[-1 for _ in range(160)]
        left10=[-1 for _ in range(160)]
        through10=[-1 for _ in range(160)]
        left12=[-1 for _ in range(160)]
        through12=[-1 for _ in range(160)]

        for i in range((simtime-1)*simRes+1):
            Vissim.Simulation.RunSingleStep()

            if i>intro_630-1700 and flag[0]==0 and i%10==5:
                Det10_val = Vissim.Net.Detectors.ItemByKey(316).AttValue('Detection')  
                Det10_val1 = Vissim.Net.Detectors.ItemByKey(317).AttValue('Detection')  
                Det12_val = Vissim.Net.Detectors.ItemByKey(320).AttValue('Detection')  
                Det12_val1 = Vissim.Net.Detectors.ItemByKey(321).AttValue('Detection')    
                det10=det10[1:]+[Det10_val+Det10_val1]    
                det12=det12[1:]+[Det12_val+Det12_val1]

            if i>intro_630-1700 and flag[0]==0 and i%10==0:
                Det10_val = Vissim.Net.Detectors.ItemByKey(316).AttValue('Detection')  
                Det10_val1 = Vissim.Net.Detectors.ItemByKey(317).AttValue('Detection')  
                Det12_val = Vissim.Net.Detectors.ItemByKey(320).AttValue('Detection')  
                Det12_val1 = Vissim.Net.Detectors.ItemByKey(321).AttValue('Detection')    
                det10=det10[:-1]+[max(Det10_val+Det10_val1, det10[-1])]    
                det12=det12[:-1]+[max(Det12_val+Det12_val1, det12[-1])]                 
                state=Vissim.Net.SignalControllers.ItemByKey(10).SGs.ItemByKey(1).AttValue('SigState')
                left10=left10[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]
                state=Vissim.Net.SignalControllers.ItemByKey(10).SGs.ItemByKey(6).AttValue('SigState')
                through10=through10[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]  
                state=Vissim.Net.SignalControllers.ItemByKey(12).SGs.ItemByKey(1).AttValue('SigState')
                left12=left12[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]
                state=Vissim.Net.SignalControllers.ItemByKey(12).SGs.ItemByKey(6).AttValue('SigState')
                through12=through12[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]    
                                                   
            if i==intro_630:
                new_Vehicle=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, 637, 1, 2.5, 53, True)
                dist=0

            if i>intro_630 and np.prod(flag)==0:
                dist+=0.146666667*float(new_Vehicle.AttValue('Speed'))
                if flag[0]==0 and i%10==0:
                    preempt=loaded_model.predict(np.array([[(i-intro_630)/10, dist]+det10+det12+left10+through10+left12+through12]))[0]
                    if preempt>0.94 or dist>=sig_location[0]-(76.266666667*12.0):
                        new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[0], 1, 0, 80, True)
                        print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-12 @', i/10, ': Preempt Probability:', preempt)
                        flag[0]=1                       

                for k in range(1, 7):
                    if flag[k]==0:
                        if i/10.0>=preemptTime[k][simnum-1]:                       
                            new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                            flag[k]=1               

        Vissim.Simulation.Stop()


