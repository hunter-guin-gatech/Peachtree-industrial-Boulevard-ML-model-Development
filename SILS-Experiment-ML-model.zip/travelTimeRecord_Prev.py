from bisect import bisect
import os
import csv

endLimit=[8200, 9400, 11100, 12000, 18600, 19300, 24050]
intersections=[12, 13, 15, 16, 18, 19, 20]

test_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        test_nums.append(int(line.split('\n')[0]))

if not os.path.isdir('./travelTimeData'):
    os.makedirs('./travelTimeData')  


endLimitTime=[]
Data=[]
for j in range(7):
    Data.append([['SimNum', 'Time-Bin', 'SideMovementNum', 'TravelTime', 'Delay']])    

for seed in range(32):
    threadnum=str(1001+seed)[1:]
    simNum=str(1000+test_nums[seed])[1:]
    print('OG Predicted: Simulation run:', simNum) 

    n=0
    i=0
    with open(f'../model-analysis/trajdata20NB/2022-08-15_PIB-RBC-Preempt-Trajectory_{simNum}_System.csv') as file:
        for line in file:
            n+=1
            f=line.split('\n')[0].split(',')
            if n>1 and f[3]=='630':
                t, d=float(f[1]), float(f[2])
                if d>=endLimit[i]:
                    T=prevt+(t-prevt)*(endLimit[i]-prevd)/(d-prevd)
                    endLimitTime.append(T)
                    i+=1
                prevt, prevd= t, d 
            if i==len(endLimit):
                break

    with open(f'../model-run-system/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{threadnum}.rsr') as file:
        for line in file:
            f=line.split(';')
            try:
                t, No, trav, delay=float(f[0]), int(f[1]),  float(f[4]), float(f[5])
                if No>=11 and No<=24:
                    j=int((No-11)/2)
                    if t>endLimitTime[j] and t<endLimitTime[j]+960:
                        BIN=int((t-endLimitTime[j])/320)
                        Data[j].append([simNum, BIN, No%2, trav, delay])
            except (ValueError, IndexError):
                continue

for i in range(7):
    outfile=f'./travelTimeData/TravelTimeDataSideStreets_{intersections[i]}_OG.csv'
    with open(outfile, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(Data[i])





