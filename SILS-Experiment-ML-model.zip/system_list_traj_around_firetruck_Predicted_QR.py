from bisect import bisect
import os
import csv

design='Predicted_QR'

def area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1)
                + x3 * (y1 - y2)) / 2.0)

def bisectFind(x, listX):
    j=bisect(listX, x)
    exist=True
    if j==0 or listX[j-1]!=x:
        exist=False
    return exist, j

def absorbTraj(vn, traj, trajdata, turntype, coord_dist):
    X1, Y1, X2, Y2, startdist=coord_dist
    dist=2.0*area(traj[0][0], traj[0][1], X1, Y1, X2, Y2)/(((X1-X2)**2 + (Y1-Y2)**2)**0.5)
    trajdata.append([vn, traj[0][2], 3.28084*dist+startdist, traj[0][3], turntype])
    for i in range(1, len(traj)):
        dist=((traj[i][0]-traj[i-1][0])**2 + (traj[i][1]-traj[i-1][1])**2)**0.5
        trajdata.append([vn, traj[i][2], trajdata[-1][2]+3.28084*dist, traj[i][3], turntype])

intersections=[10, 12, 13, 15, 16, 18, 19, 20]
coord_dist=[[1592.8, 986.1, 1596.6, 980.1, 955.2],
            [2263.1, 1417, 2266.9, 1411.1, 3570],
            [3457.7, 2171.5, 3461.5, 2165.6, 8205.8],
            [3794.3, 2369.4, 3797.6, 2363.1, 9486.5],
            [4237.3, 2594.7, 4240.4, 2588.4, 11116.9],
            [4495.2, 2728.5, 4498.5, 2722.3, 12070.5],
            [5701.4, 4121.2, 5711.7, 4118.8, 18663.7],
            [5748.9, 4330.4, 5755.7, 4329, 19367.8]]

test_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        test_nums.append(int(line.split('\n')[0]))

if not os.path.isdir('./trajdata20NB'):
    os.makedirs('./trajdata20NB')  


for seed in range(32):
    threadnum=str(1001+seed)[1:]
    simNum=str(1000+test_nums[seed])[1:]
    print('Design:', design, '; Simulation run:', simNum)

    startEV=[]
    for item in intersections:
        startEV.append(0)
        
    vehicleList=[]

    with open(f'./{design}/OutFiles/2022-08-17_CTEDD_Peachtree-Industrial-Blvd_SILS_{threadnum}.rsr') as file:
        for line in file:
            f=line.split('\n')[0].split(';')
            try:
                endT=float(f[0])
                tt=float(f[4])
                vN=int(f[2])
                tN=int(f[1])
                vtype=int(f[3])
                startT=endT-tt
                if tN>26 and tN<51:
                    j=int((tN-27)/3)
                    turn=((tN-1)%3)+1
                    vehicleList.append([str(vN)+'_'+str(j), vtype, turn, startT, endT])
                    if vtype==630:
                        startEV[j]=startT
            except (ValueError, IndexError):
                continue  

    filteredVehicleList1=[]
    for item in vehicleList:
        j=int(item[0].split('_')[1])
        if item[3]>startEV[j]-480 and item[3]<startEV[j]+480:
            filteredVehicleList1.append(item)

    filteredVehicleList1.sort(key = lambda x: (x[0], x[4]))

    vehlist=[]
    traj=[]
    filteredVehicleList=[]
    vn=-1
    minEndT=9999
    maxEndT=0    
    for item in filteredVehicleList1:
        vnum=item[0]
        if vnum!=vn:
            vehlist.append(vnum)
            traj.append([])
            filteredVehicleList.append(item)
            minEndT=min(minEndT, item[3])
            maxEndT=max(maxEndT, item[4])            
        vn=vnum

    with open(f'./{design}/OutFiles/2022-08-17_CTEDD_Peachtree-Industrial-Blvd_SILS_{threadnum}.fzp') as file:
        for line in file:
            f=line.split('\n')[0].split(';')
            try:
                t, vn, Vtype=float(f[0]), int(f[2]), int(f[4]) 
                x, y=[float(c) for c in f[3].split()][:-1]
                if t>minEndT and t<=maxEndT:
                    for item in range(len(intersections)):
                        vn_inter=str(vn)+'_'+str(item)
                        exist, j=bisectFind(vn_inter, vehlist)
                        if exist:
                            if t>filteredVehicleList[j-1][3] and t<filteredVehicleList[j-1][4]:
                                traj[j-1].append([x, y, t, Vtype])
                                break
                elif t>maxEndT:
                    break
            except (ValueError, IndexError):
                continue 

    trajdata=[['VehNum_Intersection', 'Time_s', 'Distance_ft', 'VehType', 'TurnType']]

    for i in range(len(traj)):
        vn=filteredVehicleList[i][0]
        j=int(vn.split('_')[1])
        absorbTraj(vn, traj[i], trajdata, filteredVehicleList[i][2], coord_dist[j])

    outfile=f'./trajdata20NB/2022-09-11_PIB-RBC-Preempt-Trajectory_{simNum}_{design}.csv'
    with open(outfile, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(trajdata)

   