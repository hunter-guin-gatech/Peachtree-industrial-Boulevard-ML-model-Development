from matplotlib import pyplot as plt 
import numpy as np 
from scipy.stats import ks_2samp, ttest_ind
import pandas as pd
import seaborn as sns
import os


if not os.path.isdir('./TravelTimePlots'):
    os.makedirs('./TravelTimePlots')  

def BoxplotFormat(list2D):
    maxlen=0
    for l in list2D:
        maxlen=max(maxlen, len(l))
    for i in range(len(list2D)):
        l=len(list2D[i])
        for j in range(l, maxlen):
            list2D[i].append(np.NaN)
    return np.array(list(map(list, zip(*list2D))))

traveltimeData=[]
for i in range(8):
	traveltimeData.append([[], [], [], [], [], [], [], [], [], [], [], []])

intersections=[12, 13, 15, 16, 18, 19, 20]

columns=['RBC: Predicted', 'SILS: 4n+9 Sol.', 'SILS: Predicted', 'SILS: Predicted (Queue-Recovery)']
for i in range(2):
	columns+=[j+'_'+str(i) for j in columns[:4]]

colors=['lightgreen', 'blue', 'sandybrown', 'cyan']*3

designs=['OG', 'Base', 'Predicted', 'Predicted_QR']

for i in range(7):
	for j in range(4):
		n=0
		readfile=f'./travelTimeData/TravelTimeDataSideStreets_{intersections[i]}_{designs[j]}.csv'
		with open(readfile) as file:
			for line in file:
				n+=1
				f=line.split('\n')[0].split(',')
				if n>1:
					t=float(f[-2]); BIN=int(f[1])
					k=BIN*4+j
					traveltimeData[i][k].append(t)
					traveltimeData[7][k].append(t)

	if traveltimeData[i]==[[], [], [], [], [], [], [], [], [], [], [], []]:
		continue

	Data=BoxplotFormat(traveltimeData[i])
	df = pd.DataFrame(data = Data, columns = columns)
	sns.violinplot(x="variable", y="value", data=pd.melt(df), palette=colors, inner="quartile", bw=0.05)
	means=[np.nanmean(dat) for dat in Data.T]
	plt.plot(columns, means, 'rs') 
	plt.xlabel('Variations with passage of time')
	plt.xticks([1.5, 5.5, 9.5], ['320s after EVP', '320-640s after EVP', '640-960s after EVP'])
	plt.ylabel('Travel Time [s]')
	plt.title(f'Intersection {intersections[i]}: SILS\nDifferent Experimental Setups: Side Street Travel Time')
	#plt.xticks([], [])
	minmax=[np.nanmin(Data), np.nanpercentile(Data, 98)]
	range1=minmax[1]-minmax[0]
	plt.ylim([max(minmax[0]-range1*0.1, 0),  minmax[1]+range1*0.1])
	for l in range(4):
		plt.plot([], [], label=columns[l], linewidth=10, color=colors[l])
	plt.legend(fontsize=8, ncol=3, bbox_to_anchor=(1, -0.15))
	plt.plot([0.5, 0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
	plt.plot([4.5, 4.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
	plt.plot([8.5, 8.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
	plt.plot([3.5, 3.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
	plt.plot([7.5, 7.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
	plt.savefig(f'./TravelTimePlots/SideStreet-ViolinPlot_SILS_{intersections[i]}.png', bbox_inches='tight', dpi=600) 
	plt.clf()     
	plt.close()  

Data=BoxplotFormat(traveltimeData[7])
df = pd.DataFrame(data = Data, columns = columns)
sns.violinplot(x="variable", y="value", data=pd.melt(df), palette=colors, inner="quartile", bw=0.05)
means=[np.nanmean(dat) for dat in Data.T]
plt.plot(columns, means, 'rs') 
plt.xlabel('Variations with passage of time')
plt.xticks([1.5, 5.5, 9.5], ['320s after EVP', '320-640s after EVP', '640-960s after EVP'])
plt.ylabel('Travel Time [s]')
plt.title(f'All Intersections: SILS\nDifferent Experimental Setups: Side Street Travel Time')
#plt.xticks([], [])
minmax=[np.nanmin(Data), np.nanpercentile(Data, 98)]
range1=minmax[1]-minmax[0]
plt.ylim([max(minmax[0]-range1*0.1, 0),  minmax[1]+range1*0.1])
for l in range(4):
	plt.plot([], [], label=columns[l], linewidth=10, color=colors[l])
plt.legend(fontsize=8, ncol=3, bbox_to_anchor=(1, -0.15))
plt.plot([0.5, 0.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
plt.plot([4.5, 4.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
plt.plot([8.5, 8.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, linestyle=':', color='grey')
plt.plot([3.5, 3.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.plot([7.5, 7.5], [minmax[0]-range1*0.2,  minmax[1]+range1*0.2], linewidth=1, color='black')
plt.savefig(f'./TravelTimePlots/SideStreet-ViolinPlot_SILS_System.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close()  	