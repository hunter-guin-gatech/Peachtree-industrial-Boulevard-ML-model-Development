import csv
from bisect import bisect

allowed_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
    	f=str(int(line.split('\n')[0])+1000)[1:]
    	allowed_nums.append(f)

intersections=[12, 13, 15, 16, 18, 19, 20]
thread=1000
designs=['CICO', 'Base', 'Predicted']

Data=[['simNum', 'CI-CO_Dur', 'Base_Dur', 'Predicted-Dur']]

for simNum in allowed_nums:
    thread+=1
    #print(simNum)
    data=[simNum, 0, 0, 0]
    threadnum=str(1000+thread)[1:]

    for intr in intersections:
        k=1
        for design in designs:
            fname=f'./{design}/OutFiles/2022-08-17_CTEDD_Peachtree-Industrial-Blvd_SILS_{intr}_{threadnum}.ldp'
            flagstart=0
            pstart=0; p_end=0
            with open(fname) as file:
                for line in file:
                    f=line.split('\n')[0]
                    try:
                        T=f.split('.')
                        t, checkin, checkout=float(T[0]+'.'+T[1][0]), f[-2]=='|', f[-1]=='|'
                        if flagstart==0 and checkin:
                            pstart=t 
                            flagstart=1
                        elif checkout:
                            p_end=t
                    except (ValueError, IndexError):
                        continue 
            if p_end==0:
                print(fname, pstart)
                #raise(ValueError)
            data[k]+=max((p_end-pstart), 0)
            k+=1                                                           

    Data.append(data)

with open('2022-09-11_Preempt-Duration-Summary_SILS.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   