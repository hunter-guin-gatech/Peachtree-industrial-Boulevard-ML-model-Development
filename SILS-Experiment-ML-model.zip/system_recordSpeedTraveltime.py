import csv
from bisect import bisect

scenarios=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        f=int(line.split('\n')[0])
        scenarios.append(str(f+1000)[1:])

Data=[['simNum', 'NP_TT', 'NP_Speed', 'CICO_TT', 'CICO_Speed', 'Base_TT', 'Base_Speed', 'Predicted_TT', 'Predicted_Speed', 'Predicted_QR_TT', 'Predicted_QR_Speed']]
for simNum in scenarios:
    print(simNum)
    data=[simNum]+[0 for _ in Data[0][1:]]

    for i in range(5):
        m=0
        X=[]; T=[]
        preempt=Data[0][2*i+1][:-3]
        fname=f'./trajdata20NB/2022-09-11_PIB-RBC-Preempt-Trajectory_{simNum}'+'_'+preempt+'.csv'
        with open(fname) as infile:
            for inline in infile:
                m+=1
                if m>1:
                    g=inline.split('\n')[0].split(',')
                    if int(g[3])==630 and g[0].split('_')[1]!='0':
                        x, t=float(g[2]), float(g[1])
                        X.append(x); T.append(t)

        Speed=(X[-1]-X[0])/len(T[1:])
        travelTime=(23942.5-3570)/Speed
        data[2*i+1]=travelTime
        data[2*i+2]=Speed*0.68181818              

    Data.append(data)

with open('2022-09-11_Speed-Traveltime-Summary_SILS.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   