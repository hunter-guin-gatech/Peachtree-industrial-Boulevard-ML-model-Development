import win32com.client as com
import os
import time
import pathlib
import requests
global Vissim
import ast
import sqlite3
from datetime import datetime
import shutil
import inspect as ins
import sys
import pywintypes
import stat
import numpy as np
from bisect import bisect
import csv
import time
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import f1_score
import pickle

convertProportion=lambda p: np.log(0.001) if p<=0 else (np.log(1000) if p>=1 else np.log(p / (1 - p)))

class LogitRegression(MLPRegressor):

    def fit(self, x, p):
        p = np.asarray(p)
        y = np.array(list(map(convertProportion, p)))
        return super().fit(x, y)

    def predict(self, x):
        y = super().predict(x)
        return 1.01 / (np.exp(-y) + 1)

def on_rm_error( func, path, exc_info):
    # path contains the path of the file that couldn't be removed
    # let's just assume that it's read-only and unlink it.
    os.chmod( path, stat.S_IWRITE )
    os.unlink( path )

allowed_nums=[]
with open('testing_run-num.txt') as file:
    for line in file:
        allowed_nums.append(int(line.split('\n')[0]))

prediction_files=['12NB-NN-EVP-PosExp-0.95.model', 
                    '13NB-NN-EVP-Linear-0.95.model', 
                    '15NB-NN-EVP-NegExp-0.925.model', 
                    '16NB-NN-EVP-Linear-0.93.model', 
                    '18NB-NN-EVP-NegExp-0.9.model', 
                    '19NB-NN-EVP-Sigmoid-0.98.model',
                    '20NB-NN-EVP-PosExp-0.9.model']
loaded_models=[]
for pred_file in prediction_files:
    loaded_models.append(pickle.load(open(pred_file, 'rb')))        

basefile='2022-08-17_CTEDD_Peachtree-Industrial-Blvd_SILS'

simtime = 5400
T=35225

threadnum=1000
runindex=0
while runindex<len(allowed_nums):
    #modify this line for repetition
        runindex+=1
        continue  

    seed=int((allowed_nums[runindex]-1)/32)+1
    run=allowed_nums[runindex]-32*(seed-1)-1

    threadnum+=1
    SN=str(threadnum)[1:]

    lad = os.getenv("LOCALAPPDATA")
    # %LOCALAPPDATA%/Programs/MAXTIME/resources/app/res/node_modules/@intelight/maxtime-windows/Release/maxtime
    maxtime_directory = lad + r"/Programs/MAXTIME/resources/app/res/node_modules/@intelight/maxtime-windows/Release/maxtime/tmpDatabases_1"
    if os.path.isdir(maxtime_directory):
        shutil.rmtree(maxtime_directory, onerror = on_rm_error)
    os.makedirs(maxtime_directory)          

    Vissim = com.Dispatch("Vissim.Vissim.2021")
    Filename = os.path.join(os.getcwd(), basefile+'.inpx')
    Vissim.LoadNet(Filename, False)
    Filename = os.path.join(os.getcwd(), basefile+'.layx')
    Vissim.LoadLayout(Filename)
    simRes = Vissim.Simulation.AttValue('SimRes')
    Vissim.Simulation.SetAttValue('SimPeriod', simtime)
    Vissim.Simulation.SetAttValue('UseMaxSimSpeed', True)
    Vissim.Simulation.SetAttValue('StartDate', '01.09.2019')
    Vissim.Simulation.SetAttValue('StartTm', '16:30:00')
    #Vissim.Evaluation.SetAttValue("QueuesCollectData", True)

    intro_630=T+run*50
    Vissim.Simulation.SetAttValue('RandSeed', seed) 
    #Vissim.Simulation.SetAttValue('SimSpeed', 1)
    #Vissim.ResumeUpdateGUI(True)

    Vissim.Graphics.CurrentNetworkWindow.SetAttValue("QuickMode",1)   

    flag=[0, 0, 0, 0, 0, 0, 0]
    ERV_links=[81, 638, 639, 640, 641, 642, 643]
    sig_location=[8091.5, 9310, 10971.5, 11913.5, 18503.5, 19212, 23940]

    det_vector={10: [-1 for _ in range(160)], 12: [-1 for _ in range(160)], 13: [-1 for _ in range(160)], 
              15: [-1 for _ in range(160)], 16: [-1 for _ in range(160)], 18: [-1 for _ in range(160)],
              19: [-1 for _ in range(160)], 20: [-1 for _ in range(160)]} 

    signal_vector={'left10': [-1 for _ in range(160)], 'through10': [-1 for _ in range(160)],
                  'left12': [-1 for _ in range(160)], 'through12': [-1 for _ in range(160)],
                  'left13': [-1 for _ in range(160)], 'through13': [-1 for _ in range(160)],
                  'through15': [-1 for _ in range(160)],
                  'through16': [-1 for _ in range(160)],
                  'left18': [-1 for _ in range(160)], 'through18': [-1 for _ in range(160)],
                  'through19': [-1 for _ in range(160)],
                  'left20': [-1 for _ in range(160)], 'through20': [-1 for _ in range(160)]}

    preempt_vector={12: [-1 for _ in range(160)], 13: [-1 for _ in range(160)], 15: [-1 for _ in range(160)],
                  16: [-1 for _ in range(160)], 18: [-1 for _ in range(160)], 19: [-1 for _ in range(160)]}


    preemptnow=[0, 0, 0, 0, 0, 0]
    preemptflag=[0, 0, 0, 0, 0, 0]

    maxview_det_map={10: [316, 317], 12: [320, 321], 13: [417, 418], 15: [419, 420], 16: [421, 422], 18: [423, 424], 19: [425, 426, 427], 20: [428, 429]}
    detector_status_map={10: [0, 0], 12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0, 0], 20: [0, 0]}
    preempt_det_map={12: [439, 440], 13: [441, 442], 15: [443, 444], 16: [445, 446], 18: [414, 432], 19: [433, 434]}
    preempt_status_map={12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0]}          

    det_index_map={316: 253, 317: 254, 320: 257, 321: 258, 417: 273, 418: 274, 419: 275, 420: 276, 421: 277, 422: 278, 423: 279, 424: 280, 425: 281, 426: 282, 427: 283, 428: 284, 429: 285, 439: 294, 440: 295, 441: 296, 442: 297, 443: 298, 444: 299, 445: 300, 446: 301, 414: 272, 432: 287, 433: 288, 434: 289}              

    for i in range((simtime-1)*simRes+1):
        Vissim.Simulation.RunSingleStep()
        if i>intro_630-1700 and np.prod(flag)==0:
            all_detector_status=Vissim.Net.Detectors.GetMultipleAttributes(('No', 'Detection'))
            for intr in maxview_det_map.keys():
                for m in range(len(maxview_det_map[intr])):
                    detector_status_map[intr][m]+=all_detector_status[det_index_map[maxview_det_map[intr][m]]][1]

            for intr in preempt_det_map.keys():
                for m in range(len(preempt_det_map[intr])):
                    preempt_status_map[intr][m]+=all_detector_status[det_index_map[preempt_det_map[intr][m]]][1]                                  

            if i%10==0:
                for intr in det_vector.keys():
                  det_vector[intr]=det_vector[intr][1:]+[sum([int(m>0) for m in detector_status_map[intr]])]

                p=0
                for intr in preempt_vector.keys():
                    preemptflag[p]=sum([int(m>0) for m in preempt_status_map[intr]])

                    if flag[p]*preemptnow[p]==1:
                        if preemptflag[p]>0:
                            preemptnow[p]=0

                    preempt_vector[intr]=preempt_vector[intr][1:]+[preemptnow[p]] 
                    p+=1

                for intr in signal_vector.keys():
                  if intr[:4]=='left':
                      sigKey=1
                  else:
                      sigKey=6

                  state=Vissim.Net.SignalControllers.ItemByKey(int(intr[-2:])).SGs.ItemByKey(sigKey).AttValue('SigState')
                  sigNum=1 if state=='GREEN' else (0 if state=='RED' else 2)
                  signal_vector[intr]=signal_vector[intr][1:]+[sigNum] 

                detector_status_map={10:[0, 0], 12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0, 0], 20: [0, 0]}
                preempt_status_map={12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0]}   

        if i==intro_630:
            new_Vehicle=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, 637, 1, 2.5, 53, True)
            print('Random Seed:', seed, ': SILS Preemption: Engine introduced @', intro_630/10)
            dist=0

        if i>intro_630 and np.prod(flag)==0:
            dist+=0.146666667*float(new_Vehicle.AttValue('Speed'))  
            k=0
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[10]+det_vector[12]+signal_vector['left10']+signal_vector['through10']+signal_vector['left12']+signal_vector['through12']]))[0]
                if preempt>0.94 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1

            k=1
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[10]+det_vector[12]+preempt_vector[12]+det_vector[13]+signal_vector['left10']+signal_vector['through10']+signal_vector['left12']+signal_vector['through12']+signal_vector['left13']+signal_vector['through13']]))[0]
                if preempt>0.95 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1 

            k=2
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[12]+preempt_vector[12]+det_vector[13]+preempt_vector[13]+det_vector[15]+signal_vector['left12']+signal_vector['through12']+signal_vector['left13']+signal_vector['through13']+signal_vector['through15']]))[0]
                if preempt>0.925 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1   

            k=3
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[13]+preempt_vector[13]+det_vector[15]+preempt_vector[15]+det_vector[16]+signal_vector['left13']+signal_vector['through13']+signal_vector['through15']+signal_vector['through16']]))[0]
                if preempt>0.93 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1  

            k=4
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[15]+preempt_vector[15]+det_vector[16]+preempt_vector[16]+det_vector[18]+signal_vector['through15']+signal_vector['through16']+signal_vector['left18']+signal_vector['through18']]))[0]
                if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1                 

            k=5
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[16]+preempt_vector[16]+det_vector[18]+preempt_vector[18]+det_vector[19]+signal_vector['through16']+signal_vector['left18']+signal_vector['through18']+signal_vector['through19']]))[0]
                if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    preemptnow[k]=1
                    flag[k]=1                 

            k=6
            if flag[k]==0 and i%10==0:
                preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[18]+preempt_vector[18]+det_vector[19]+preempt_vector[19]+det_vector[20]+signal_vector['left18']+signal_vector['through18']+signal_vector['through19']+signal_vector['left20']+signal_vector['through20']]))[0]
                if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
                    new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                    flag[k]=1   
    

    Vissim.Simulation.Stop()

    intersectionDetails=[(3419, 'MedLock Br Rd', '10-Maxtime', [956, 3419]),
                        (8093, 'S.Old Peachtree Rd', '12-Maxtime', [3592, 8093]),
                        (9310, 'Highwoods Center', '13-Maxtime', [8191.5, 9310]),
                        (10971.5, 'Pickneyville Park', '15-Maxtime', [9409.5, 10971.5]),
                        (11913.5, 'S.Berkeley Lk Rd', '16-Maxtime', [11078.5, 11913.5]),
                        (18503.5, 'N.Berkeley Lk Rd', '18-Maxtime', [12035.5, 18503.5]),
                        (19212, 'Summit Ridge Pkwy', '19-Maxtime', [18622.5, 19212]),
                        (23940, 'Howell Ferry Rd', '20-Maxtime', [19291.5, 23940])]

    sigdata=[]
    for intr in intersectionDetails:
        sigdata.append([[0], ['red']])
    with open('./OutFiles/'+basefile+'_'+SN+'.lsa') as file:
        for line in file:
            f=line.split(';')
            try:
                t, ph, state=int(float(f[0])), str(int(f[2]))+'-'+str(int(f[3])), ''.join(f[4].split())
                for j in range(len(intersectionDetails)):
                    if len(intersectionDetails[j])==4:
                        intrNo, intrType=intersectionDetails[j][2].split('-')
                    else:
                        intrNo=str(intersectionDetails[j][2])
                    if ph==intrNo+'-6':
                        st=int(sigdata[j][0][-1])+1; st_st=sigdata[j][1][-1]
                        for t1 in range(st, t):
                            sigdata[j][0].append(t1); sigdata[j][1].append(st_st)
                        sigdata[j][0].append(t); sigdata[j][1].append(state)
                        break
            except (ValueError, IndexError):
                continue
    flag=0
    for i in sigdata:
        for j in i[1]:
            if j=='off':
                flag+=1
    if flag>len(intersectionDetails):
        print('"Off"-Issue encountered with Maxtime signals...redoing this run...')
        filelist=os.listdir('./OutFiles/')
        for file in filelist:
            if len(file.split(SN))==2 and len(file.split(basefile))==2:
                os.remove('./OutFiles/'+file)
        os.remove(basefile+'_'+SN+'.err')
        os.remove(basefile+'.results/'+str(int(SN))+'.db')
        threadnum-=1
    else:
        runindex+=1
         