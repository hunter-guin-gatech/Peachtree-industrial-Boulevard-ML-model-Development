import win32com.client as com
import os
import time
import pathlib
import requests
global Vissim
import ast
import sqlite3
from datetime import datetime
import shutil
import inspect as ins
import sys
import pywintypes
import numpy as np
from bisect import bisect
import csv
import time
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import f1_score
import pickle

convertProportion=lambda p: np.log(0.001) if p<=0 else (np.log(1000) if p>=1 else np.log(p / (1 - p)))

class LogitRegression(MLPRegressor):

    def fit(self, x, p):
        p = np.asarray(p)
        y = np.array(list(map(convertProportion, p)))
        return super().fit(x, y)

    def predict(self, x):
        y = super().predict(x)
        return 1.01 / (np.exp(-y) + 1)

      
preemptTime=[[], [], [], [], [], [], []]
n=0
with open('1_PreemptSummary_12NB-13NB-15NB-16NB-18NB-19NB-20NB.csv') as file:
    for line in file:
        f=line.split('\n')[0].split(',')
        n+=1
        if n>1:
            for i in range(7):
                preemptTime[i].append(float(f[2*i+3])-0.8)

allowed_nums=[]
with open('testing_run-num.txt') as file:
    for line in file:
        allowed_nums.append(int(line.split('\n')[0]))

prediction_files=['12NB-NN-EVP-PosExp-0.95.model', 
                    '13NB-NN-EVP-Linear-0.95.model', 
                    '15NB-NN-EVP-NegExp-0.925.model', 
                    '16NB-NN-EVP-Linear-0.93.model', 
                    '18NB-NN-EVP-NegExp-0.9.model', 
                    '19NB-NN-EVP-Sigmoid-0.98.model',
                    '20NB-NN-EVP-PosExp-0.9.model']
loaded_models=[]
for pred_file in prediction_files:
    loaded_models.append(pickle.load(open(pred_file, 'rb')))           
                
simtime = 5400
T=35225
fname='2022-08-17_CTEDD_Peachtree-Industrial-Blvd_SILS'
Vissim = com.Dispatch("Vissim.Vissim.2021")
Filename = os.path.join(os.getcwd(), fname+'.inpx')
Vissim.LoadNet(Filename, False)
Filename = os.path.join(os.getcwd(), fname+'.layx')
Vissim.LoadLayout(Filename)
Vissim.Simulation.SetAttValue('StartDate', '01.09.2019')
Vissim.Simulation.SetAttValue('StartTm', '16:30:00')

simnum=0
for seed in range(1, 6):
    for run in range(0, 160, 5):
        simnum+=1
        if simnum!=1:
        #modify this line for repetition
            continue
            
        intro_630=T+run*10

        Vissim.Net.Scripts.SetAllAttValues('RunType', 1)
        simRes = Vissim.Simulation.AttValue('SimRes')
        Vissim.Simulation.SetAttValue('SimPeriod', simtime)
        Vissim.Simulation.SetAttValue('UseMaxSimSpeed', True)
        Vissim.Simulation.SetAttValue('RandSeed', seed)
        Vissim.Graphics.CurrentNetworkWindow.SetAttValue("QuickMode",1) 

        # flag=[0, 0, 0, 0, 0, 0, 0]
        # ERV_links=[81, 638, 639, 640, 641, 642, 643]
        # sig_location=[8091.5, 9310, 10971.5, 11913.5, 18503.5, 19212, 23940]

        # det_vector={10: [-1 for _ in range(160)], 12: [-1 for _ in range(160)], 13: [-1 for _ in range(160)], 
        # 			15: [-1 for _ in range(160)], 16: [-1 for _ in range(160)], 18: [-1 for _ in range(160)],
        # 			19: [-1 for _ in range(160)], 20: [-1 for _ in range(160)]} 

        # signal_vector={'left10': [-1 for _ in range(160)], 'through10': [-1 for _ in range(160)],
        # 				'left12': [-1 for _ in range(160)], 'through12': [-1 for _ in range(160)],
        # 				'left13': [-1 for _ in range(160)], 'through13': [-1 for _ in range(160)],
        # 				'through15': [-1 for _ in range(160)],
        # 				'through16': [-1 for _ in range(160)],
        # 				'left18': [-1 for _ in range(160)], 'through18': [-1 for _ in range(160)],
        # 				'through19': [-1 for _ in range(160)],
        # 				'left20': [-1 for _ in range(160)], 'through20': [-1 for _ in range(160)]}

        # preempt_vector={12: [-1 for _ in range(160)], 13: [-1 for _ in range(160)], 15: [-1 for _ in range(160)],
        # 				16: [-1 for _ in range(160)], 18: [-1 for _ in range(160)], 19: [-1 for _ in range(160)]}


        # preemptnow=[0, 0, 0, 0, 0, 0]
        # preemptflag=[0, 0, 0, 0, 0, 0]

        # maxview_det_map={10: [316, 317], 12: [320, 321], 13: [417, 418], 15: [419, 420], 16: [421, 422], 18: [423, 424], 19: [425, 426, 427], 20: [428, 429]}
        # detector_status_map={10: [0, 0], 12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0, 0], 20: [0, 0]}
        # preempt_det_map={12: [439, 440], 13: [441, 442], 15: [443, 444], 16: [445, 446], 18: [414, 432], 19: [433, 434]}
        # preempt_status_map={12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0]}


        for i in range((simtime-1)*simRes+1):
            Vissim.Simulation.RunSingleStep()
            if i%10==0:
                detection=Vissim.Net.Detectors.GetMultipleAttributes(('No', 'Detection'))
                print(detection)


            # if i>intro_630-1700 and np.prod(flag)==0:
            #     for intr in maxview_det_map.keys():
            #         for m in range(len(maxview_det_map[intr])):
            #             detector_status_map[intr][m]+=Vissim.Net.Detectors.ItemByKey(maxview_det_map[intr][m]).AttValue('Detection')

            #     for intr in preempt_det_map.keys():
            #         for m in range(len(preempt_det_map[intr])):
            #             preempt_status_map[intr][m]+=Vissim.Net.Detectors.ItemByKey(preempt_det_map[intr][m]).AttValue('Detection')                                       

            #     if i%10==0:
            #     	for intr in det_vector.keys():
            #     		det_vector[intr]=det_vector[intr][1:]+[sum([int(m>0) for m in detector_status_map[intr]])]

            #         p=0
            #         for intr in preempt_vector.keys():
            #         	preemptflag[p]=[sum([int(m>0) for m in preempt_status_map[intr]])]

	           #          if flag[p]*preemptnow[p]==1:
	           #              if preemptflag[p]>0:
	           #                  preemptnow[p]=0

	           #          preempt_vector[intr]=preempt_vector[intr][1:]+[preemptnow[p]] 
	           #          p+=1

	           #      for intr in signal_vector.keys():
	           #      	if intr[:4]=='left':
	           #      		sigKey=1
	           #      	else:
	           #      		sigKey=6

            #     		state=Vissim.Net.SignalControllers.ItemByKey(int(intr[-2:])).SGs.ItemByKey(sigKey).AttValue('SigState')
            #     		sigNum=1 if state=='GREEN' else (0 if state=='RED' else 2)
            #     		signal_vector[intr]=signal_vector[intr][1:]+[sigNum] 

            #         detector_status_map={10:[0, 0], 12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0, 0], 20: [0, 0]}
            #         preempt_status_map={12: [0, 0], 13: [0, 0], 15: [0, 0], 16: [0, 0], 18: [0, 0], 19: [0, 0]}                                                                                                    
                                                   
            # if i==intro_630:
            #     new_Vehicle=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, 637, 1, 2.5, 53, True)
            #     dist=0

            # if i>intro_630 and np.prod(flag)==0:
            #     dist+=0.146666667*float(new_Vehicle.AttValue('Speed'))  
            #     k=0
            #     if flag[k]==0 and i%10==0:
            #         preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[10]+det_vector[12]+signal_vector['left10']+signal_vector['through10']+signal_vector['left12']+signal_vector['through12']]))[0]
            #         if preempt>0.94 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-12 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1

            #     k=1
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[10]+det_vector[12]+preempt_vector[12]+det_vector[13]+signal_vector['left10']+signal_vector['through10']+signal_vector['left12']+signal_vector['through12']+signal_vector['left13']+signal_vector['through13']]))[0]
            #         if preempt>0.95 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-13 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1 

            #     k=2
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[12]+preempt_vector[12]+det_vector[13]+preempt_vector[13]+det_vector[15]+signal_vector['left12']+signal_vector['through12']+signal_vector['left13']+signal_vector['through13']+signal_vector['through15']]))[0]
            #         if preempt>0.925 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-15 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1   

            #     k=3
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[13]+preempt_vector[13]+det_vector[15]+preempt_vector[15]+det_vector[16]+signal_vector['left13']+signal_vector['through13']+signal_vector['through15']+signal_vector['through16']]))[0]
            #         if preempt>0.93 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-16 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1  

            #     k=4
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[15]+preempt_vector[15]+det_vector[16]+preempt_vector[16]+det_vector[18]+signal_vector['through15']+signal_vector['through16']+signal_vector['left18']+signal_vector['through18']]))[0]
            #         if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-18 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1                 

            #     k=5
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[16]+preempt_vector[16]+det_vector[18]+preempt_vector[18]+det_vector[19]+signal_vector['through16']+signal_vector['left18']+signal_vector['through18']+signal_vector['through19']]))[0]
            #         if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-19 @', i/10, ': Preempt Probability:', preempt)
            #             preemptnow[k]=1
            #             flag[k]=1                 

            #     k=6
            #     if flag[k]==0 and i%10==0:
            #     	preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10, dist]+det_vector[18]+preempt_vector[18]+det_vector[19]+preempt_vector[19]+det_vector[20]+signal_vector['left18']+signal_vector['through18']+signal_vector['through19']+signal_vector['left20']+signal_vector['through20']]))[0]
            #         if preempt>0.9 or dist>=sig_location[k]-(76.266666667*12.0):
            #             new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
            #             print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-20 @', i/10, ': Preempt Probability:', preempt)
            #             flag[k]=1                                                                                                                    

        print('\n')
        Vissim.Simulation.Stop()