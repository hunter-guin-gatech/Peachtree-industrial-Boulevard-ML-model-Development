import os
import shutil

def copyEdit(src, dst, linenum, line):
    n=0
    with open(src) as infile:
        with open(dst, 'w+') as outfile:
            for l in infile:
                n+=1
                if n==linenum:
                    outfile.write(line)
                else:
                    outfile.write(l)

diff_line_num=77

filelist=os.listdir('./')

rep_size=[5, 5, 5, 5, 5, 5, 2]

filextent=[]
k=1
last_extent=0

for item in rep_size:
    new_extent=last_extent+item
    filextent.append([k, last_extent+1, new_extent])
    k+=1; last_extent=new_extent

for item in filextent:
    newloc='./run_'+str(item[0])
    if not os.path.isdir(newloc):
        os.makedirs(newloc) 

    for file in filelist:
        if len(file.split('Replicate-Runs'))==2:
            copyEdit(file, newloc+'/'+file[:-3]+'_'+str(item[0])+'.py', diff_line_num, f'        if not simnum in allowed_nums[{item[1]-1}:{item[2]}]:\n')
        else:
            shutil.copyfile(file, newloc+'/'+file)

