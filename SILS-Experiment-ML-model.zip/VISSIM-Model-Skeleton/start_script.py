# create list of signal controllers in 'SCs'

# VISSIM ID, file name, ip address (this will almost always be 127.0.0.1), VISSIM Port (same as set in scprops file), web port, redis port
# web port and redis port can be any open port on the computer
# The web interface can be reached via the web port

'''

SCs = [
#    VISSIM ID, file name, ip address, VISSIM Port (same as set in scprops file), web port, redis port
    (1, "Database Name 1", "127.0.0.1", 9931, 81, 1010),
    (2, "Database Name 2", "127.0.0.1", 9932, 82, 1020),
    (3, "Database Name 3", "127.0.0.1", 9933, 83, 1030),
]
'''

SCs = [
#    VISSIM ID, file name, ip address, VISSIM Port (same as set in scprops file), web port, redis port
    (10, "./maxtime-databases/133-19-1221-PIB@MedlockBr-ver2111_EVPEnabled_134", "127.0.0.1", 1210, 7910, 1010),
    (12, "./maxtime-databases/134-19-1221-PIB@SOldPtree-ver2111_EVPEnabled", "127.0.0.1", 1212, 7912, 1012),
    (13, "./maxtime-databases/368-19-1221-PIB@HighwoodsCtr-ver2111_EVPEnabled", "127.0.0.1", 1213, 7913, 1013),
    (15, "./maxtime-databases/561-19-1221-PIB@PinkneyvlPark-ver2111_EVPEnabled", "127.0.0.1", 1215, 7915, 1015),
    (16, "./maxtime-databases/136-19-1221-PIB@SBerkly-ver2111_EVPEnabled", "127.0.0.1", 1216, 7916, 1016),
    (18, "./maxtime-databases/135-19-1221-PIB@NorthBerkly-ver2111_EVPEnabled", "127.0.0.1", 1218, 7918, 1018),
    (19, "./maxtime-databases/515-19-1221-PIB@SummittRg-ver2111_EVPEnabled", "127.0.0.1", 1219, 7919, 1019),
    (20, "./maxtime-databases/137-19-1221-PIB@HowellFerry-ver2111_EVPEnabled", "127.0.0.1", 1220, 7920, 1020)

]

# Navigate in Windows Explorer to %LOCALAPPDATA%/Programs/MAXTIME/resources/app/res/node_modules/@intelight/maxtime-windows/Release/maxtime
# If that folder is found, leave the maxtime_root_directory below set to None.
# If that folder is not found, provide the address to the installation of Maxtime 2.0 Windows app on your computer. (This is unusual)

maxtime_root_directory = None


## No Edits Needed Below This Line To Run VISSIM##



from subprocess import Popen as po
from subprocess import call as call
import subprocess
import os
from time import sleep
import shutil
import sys
import sqlite3
import glob
import errno, os, stat

def handleRemoveReadonly(func, path, exc):
  excvalue = exc[1]
  if func in (os.rmdir, os.remove) and excvalue.errno == errno.EACCES:
      os.chmod(path, stat.S_IRWXU| stat.S_IRWXG| stat.S_IRWXO) # 0777
      func(path)
  else:
      raise

abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)

sys.path.append(dname)

if maxtime_root_directory is None:
    lad = os.getenv("LOCALAPPDATA")
    # %LOCALAPPDATA%/Programs/MAXTIME/resources/app/res/node_modules/@intelight/maxtime-windows/Release/maxtime
    maxtime_root_directory = lad + r"/Programs/MAXTIME/resources/app/res/node_modules/@intelight/maxtime-windows/Release/maxtime"

startupinfo = subprocess.STARTUPINFO()
startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

class Signal_Controller:
    def __init__(self, id, database, ip, port, webport, redisport):
        self.database = "%s/%s" % (dname,database)
        self.id = id
        self.ip = ip
        self.port = port
        self.webport = webport
        self.redisport = redisport
        self.processes_started = []
    def start(self):
        databasePath = "%s/tmpDatabases/%s" % (maxtime_root_directory, self.id)
        os.makedirs(databasePath)
        self.databasePath = databasePath
    # copy database to tmp
    # copy from self.database to databasePath
        shutil.copy(self.database, "%s/database.bin" % databasePath)
        # start redis (Do I need this?)
        self.processes_started.append(po(
            ["%s/redis/redis-server.exe" % maxtime_root_directory, "redis.windows.conf", "--port", str(self.redisport)],
            cwd="%s/redis" % maxtime_root_directory, startupinfo=startupinfo))
        sleep(3)
        # --Start Controller--
        # StartDatabaseServer
        self.processes_started.append(po(
            ["%s/bin/DatabaseServer.exe" % maxtime_root_directory, "-id", str(self.id), "-s", self.database, "-f",
             "%s/database.bin" % databasePath, "-redisport", str(self.redisport)],
            cwd=maxtime_root_directory, env={"PROGRAMDATA": r"C:\ProgramData"}, startupinfo=startupinfo))

        # StartLogic
        self.processes_started.append(
            po(["%s/bin/logic.exe" % maxtime_root_directory, "-id", str(self.id), "-ip", self.ip, "-vp", str(self.port), "-s", '1', "-redisport",str(self.redisport)],
               cwd=maxtime_root_directory, startupinfo=startupinfo))

        # StartNginx
        cwd = "%s/openresty" % maxtime_root_directory
        self.processes_started.append(po(
            ["%s/luajit.exe" % cwd, '%s/lua/maxprofile/migrate.lua' % cwd, 'up', '%s/lua/maxprofile/migrations/' % cwd],
            cwd=cwd, env={
                "DATABASE": "C:/ProgramData/intelight/Profile/profile.db", "SECRET": "profileserver",
                "LUA_PATH": '%s/lua/?.lua;%s/?.lua' % (cwd,cwd),
                "LUA_CPATH": '%s/lua/?.dll;%s/?.dll' % (cwd,cwd)
            }, startupinfo=startupinfo, shell=True))
        product = "maxtime"
        call(["%s/luajit.exe"%cwd,"%s/tools/EngineEggsTemplateEngine.lua"%cwd,"-f","%s/tools/mt_windows.conf.template"%cwd, "-d", 'SERVER_PORT=%s;PRODUCT=*;INIT=init_by_lua_file %s/lua/init/%s_init.lua;'%(self.webport, cwd,product), "-s", '%s/conf/mt_windows_%s.conf'%(cwd,self.id)],cwd = cwd, env={"DATABASE": "C:/ProgramData/intelight/Profile/profile.db",
                "SECRET": "profileserver", "LUA_PATH": './lua/?.lua;./?.lua',
                "LUA_CPATH": './lua/?.dll;./?.dll', "REDIS_PORT": str(self.redisport)}, shell=True)
        self.processes_started.append(po(["%s/start_server.bat"%dname,str(self.id),str(self.redisport)], startupinfo=startupinfo))
        # StartSSM
        self.processes_started.append(po(["%s/bin/ssm.exe"%maxtime_root_directory, "-id", str(self.id)], cwd=maxtime_root_directory, startupinfo=startupinfo))
        # StartCommAgent
        self.processes_started.append(po(["%s/bin/comm-agent.exe"%maxtime_root_directory, "-id", str(self.id), "-redisport", str(self.redisport)], cwd=maxtime_root_directory, startupinfo=startupinfo))
        # StartCommApps
        self.processes_started.append(po(["%s/bin/comm-apps.exe"%maxtime_root_directory, "-id", str(self.id), "-redisport", str(self.redisport), "-archiveroot", "%s/"%self.databasePath, "-asclog", "%s/asclog.db"%self.databasePath, "-tsslog", "%s/tsslog.db"%self.databasePath], cwd=maxtime_root_directory, startupinfo=startupinfo))

def sql_fix(self):
    con = sqlite3.connect("%s/asclog.db"%self.databasePath)
    command1 = 'DROP TRIGGER "main"."RemoveOld"'
    command2 = """CREATE TRIGGER RemoveOther AFTER INSERT ON Event BEGIN DELETE FROM Event WHERE EventTypeID NOT IN (1,8,10,81,82) ; END"""
    cur = con.cursor()
    try:
        cur.execute(command1)
        cur.execute(command2)
        con.commit()
    except Exception as e:
            if str(e) != "no such trigger: main.RemoveOld":
                raise
    finally:
        con.close()
        
scs = [Signal_Controller(*x) for x in SCs]
    
def start():
    files = glob.glob(maxtime_root_directory+'/tmpDatabases/*')
    for f in files:
        shutil.rmtree(f, ignore_errors=False, onerror=handleRemoveReadonly)

    for sc in scs:
        sc.start()
            
def fix():
        for sc in scs:
            sc.sql_fix()
            
def end():
    #List_Sim_Runs   = Vissim.Net.SimulationRuns.GetMultipleAttributes(["No"])
    #sim_run=List_Sim_Runs[-1][0]
    for sc in scs:
        for p in reversed(sc.processes_started):
            if p.poll() is None:
                    try:
                        p.terminate()
                    except WindowsError:
                            raise WindowsError("%s-%s"%(p.pid,p.args))
                    sleep(5)
        #shutil.copyfile("%s/asclog.db"%sc.databasePath,"%s/SPM-Run%s-I%s.db"%(os.path.dirname(dname),sim_run,sc.id))
        try:
                shutil.rmtree(sc.databasePath, ignore_errors=False, onerror=handleRemoveReadonly)
        except WindowsError:
                raise WindowsError("RemoveTree")
    os.system('taskkill /f /im nginx.exe')
