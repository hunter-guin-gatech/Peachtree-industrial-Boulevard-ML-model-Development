import os
import shutil

def copyEdit(src, dst, linenum, line):
    n=0
    with open(src) as infile:
        with open(dst, 'w+') as outfile:
            for l in infile:
                n+=1
                if n==linenum:
                    outfile.write(line)
                else:
                    outfile.write(l)

diff_line_num=75

filelist=os.listdir('./')

rep_size=[11, 11, 11, 13, 13, 12, 14, 14, 14, 12, 12, 11, 6, 6]

filextent=[]
k=1
last_extent=0

for item in rep_size:
    new_extent=last_extent+item
    filextent.append([k, last_extent+1, new_extent])
    k+=1; last_extent=new_extent

for item in filextent:
    newloc='./run_'+str(item[0])
    if not os.path.isdir(newloc):
        os.makedirs(newloc) 

    for file in filelist:
        if len(file.split('Replicate-Runs'))==2:
            copyEdit(file, newloc+'/'+file[:-3]+'_'+str(item[0])+'.py', diff_line_num, '            if simnum<'+str(item[1])+' or simnum>'+str(item[2])+':\n')
        # else:
        #     shutil.copyfile(file, newloc+'/'+file)