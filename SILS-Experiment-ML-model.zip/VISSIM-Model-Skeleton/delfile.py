import os
import time
import stat
import shutil

def on_rm_error( func, path, exc_info):
    # path contains the path of the file that couldn't be removed
    # let's just assume that it's read-only and unlink it.
    os.chmod( path, stat.S_IWRITE )
    os.unlink( path )

def recreatewait(dirname):
    try:
        if os.path.isdir(dirname):
            shutil.rmtree(dirname, onerror = on_rm_error)
    except OSError:
        time.sleep(5)
        recreatewait(dirname)


recreatewait('run_14') 










         