import win32com.client as com
import os
import time
import pathlib
import requests
global Vissim
import ast
import sqlite3
from datetime import datetime
import shutil
import inspect as ins
import sys
import pywintypes
import numpy as np
from bisect import bisect
import csv
import time
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import f1_score
import pickle

convertProportion=lambda p: np.log(0.001) if p<=0 else (np.log(1000) if p>=1 else np.log(p / (1 - p)))

class LogitRegression(MLPRegressor):

    def fit(self, x, p):
        p = np.asarray(p)
        y = np.array(list(map(convertProportion, p)))
        return super().fit(x, y)

    def predict(self, x):
        y = super().predict(x)
        return 1.01 / (np.exp(-y) + 1)

      
preemptTime=[[], [], [], [], [], [], []]
n=0
with open('1_PreemptSummary_12NB-13NB-15NB-16NB-18NB-19NB-20NB.csv') as file:
    for line in file:
        f=line.split('\n')[0].split(',')
        n+=1
        if n>1:
            for i in range(7):
                preemptTime[i].append(float(f[2*i+3])-0.8)

allowed_nums=[]
with open('testing_run-num.txt') as file:
    for line in file:
        allowed_nums.append(int(line.split('\n')[0]))

prediction_files=['12NB-NN-EVP-PosExp-0.95.model', 
                    '13NB-NN-EVP-Linear-0.95.model', 
                    '15NB-NN-EVP-NegExp-0.925.model', 
                    '16NB-NN-EVP-Linear-0.93.model', 
                    '18NB-NN-EVP-NegExp-0.9.model', 
                    '19NB-NN-EVP-Sigmoid-0.98.model',
                    '20NB-NN-EVP-PosExp-0.9.model']
loaded_models=[]
for pred_file in prediction_files:
    loaded_models.append(pickle.load(open(pred_file, 'rb')))           
                
simtime = 5400
T=35225
fname='2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE'
Vissim = com.Dispatch("Vissim.Vissim.2021")
Filename = os.path.join(os.getcwd(), fname+'.inpx')
Vissim.LoadNet(Filename, False)
Filename = os.path.join(os.getcwd(), fname+'.layx')
Vissim.LoadLayout(Filename)
Vissim.Simulation.SetAttValue('StartDate', '01.09.2019')
Vissim.Simulation.SetAttValue('StartTm', '16:30:00')

simnum=0
for seed in range(1, 6):
    for run in range(0, 160, 5):
        simnum+=1
        #modify this line for repetition
            continue
            
        intro_630=T+run*10

        Vissim.Net.Scripts.SetAllAttValues('RunType', 1)
        simRes = Vissim.Simulation.AttValue('SimRes')
        Vissim.Simulation.SetAttValue('SimPeriod', simtime)
        Vissim.Simulation.SetAttValue('UseMaxSimSpeed', True)
        Vissim.Simulation.SetAttValue('RandSeed', seed+5)
        Vissim.Graphics.CurrentNetworkWindow.SetAttValue("QuickMode",1) 

        flag=[0, 0, 0, 1, 1, 1, 1]
        ERV_links=[81, 638, 639, 640, 641, 642, 643]
        sig_location=[8091.5, 9310, 10971.5, 11913.5, 18503.5, 19212, 23940]
        det10=[-1 for _ in range(160)]
        det12=[-1 for _ in range(160)]
        det13=[-1 for _ in range(160)]
        det15=[-1 for _ in range(160)]   

        left10=[-1 for _ in range(160)]
        through10=[-1 for _ in range(160)]
        left12=[-1 for _ in range(160)]
        through12=[-1 for _ in range(160)]
        left13=[-1 for _ in range(160)]
        through13=[-1 for _ in range(160)] 
        through15=[-1 for _ in range(160)]  

        preempt12=[-1 for _ in range(160)] 
        preempt13=[-1 for _ in range(160)]  

        preemptnow=[0, 0]
        preemptflag=[0, 0]
        for i in range((simtime-1)*simRes+1):
            Vissim.Simulation.RunSingleStep()

            if i>intro_630-1700 and np.prod(flag)==0 and i%10==5:
                Det10_val = Vissim.Net.Detectors.ItemByKey(316).AttValue('Detection')  
                Det10_val1 = Vissim.Net.Detectors.ItemByKey(317).AttValue('Detection')  
                Det12_val = Vissim.Net.Detectors.ItemByKey(320).AttValue('Detection')  
                Det12_val1 = Vissim.Net.Detectors.ItemByKey(321).AttValue('Detection')    
                Det13_val = Vissim.Net.Detectors.ItemByKey(417).AttValue('Detection')  
                Det13_val1 = Vissim.Net.Detectors.ItemByKey(418).AttValue('Detection')  
                Det15_val = Vissim.Net.Detectors.ItemByKey(419).AttValue('Detection')  
                Det15_val1 = Vissim.Net.Detectors.ItemByKey(420).AttValue('Detection') 
                Det16_val = Vissim.Net.Detectors.ItemByKey(421).AttValue('Detection')  
                Det16_val1 = Vissim.Net.Detectors.ItemByKey(422).AttValue('Detection')                 

                Preempt_Det12_val = Vissim.Net.Detectors.ItemByKey(439).AttValue('Detection')  
                Preempt_Det12_val1 = Vissim.Net.Detectors.ItemByKey(440).AttValue('Detection')      
                Preempt_Det13_val = Vissim.Net.Detectors.ItemByKey(441).AttValue('Detection')  
                Preempt_Det13_val1 = Vissim.Net.Detectors.ItemByKey(442).AttValue('Detection')                    

                det10=det10[1:]+[Det10_val+Det10_val1]
                det12=det12[1:]+[Det12_val+Det12_val1]
                det13=det13[1:]+[Det13_val+Det13_val1]
                det15=det15[1:]+[Det15_val+Det15_val1]

                preemptflag[0]=Preempt_Det12_val+Preempt_Det12_val1
                preemptflag[1]=Preempt_Det13_val+Preempt_Det13_val1

            if i>intro_630-1700 and np.prod(flag)==0 and i%10==0:
                Det10_val = Vissim.Net.Detectors.ItemByKey(316).AttValue('Detection')  
                Det10_val1 = Vissim.Net.Detectors.ItemByKey(317).AttValue('Detection')  
                Det12_val = Vissim.Net.Detectors.ItemByKey(320).AttValue('Detection')  
                Det12_val1 = Vissim.Net.Detectors.ItemByKey(321).AttValue('Detection')    
                Det13_val = Vissim.Net.Detectors.ItemByKey(417).AttValue('Detection')  
                Det13_val1 = Vissim.Net.Detectors.ItemByKey(418).AttValue('Detection')  
                Det15_val = Vissim.Net.Detectors.ItemByKey(419).AttValue('Detection')  
                Det15_val1 = Vissim.Net.Detectors.ItemByKey(420).AttValue('Detection')                

                Preempt_Det12_val = Vissim.Net.Detectors.ItemByKey(439).AttValue('Detection')  
                Preempt_Det12_val1 = Vissim.Net.Detectors.ItemByKey(440).AttValue('Detection')      
                Preempt_Det13_val = Vissim.Net.Detectors.ItemByKey(441).AttValue('Detection')  
                Preempt_Det13_val1 = Vissim.Net.Detectors.ItemByKey(442).AttValue('Detection')                   

                det10=det10[:-1]+[max(Det10_val+Det10_val1, det10[-1])] 
                det12=det12[:-1]+[max(Det12_val+Det12_val1, det12[-1])] 
                det13=det13[:-1]+[max(Det13_val+Det13_val1, det13[-1])] 
                det15=det15[:-1]+[max(Det15_val+Det15_val1, det15[-1])] 

                if flag[0]*preemptnow[0]==1:
                    preemptflag[0]=max(Preempt_Det12_val+Preempt_Det12_val1, preemptflag[0])
                    if preemptflag[0]>0:
                        preemptnow[0]=0

                preempt12=preempt12[1:]+[preemptnow[0]]

                if flag[1]*preemptnow[1]==1:
                    preemptflag[1]=max(Preempt_Det13_val+Preempt_Det13_val1, preemptflag[1])
                    if preemptflag[1]>0:
                        preemptnow[1]=0

                preempt13=preempt13[1:]+[preemptnow[1]]  
                                                                      

                state=Vissim.Net.SignalControllers.ItemByKey(10).SGs.ItemByKey(1).AttValue('SigState')
                left10=left10[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]
                state=Vissim.Net.SignalControllers.ItemByKey(10).SGs.ItemByKey(6).AttValue('SigState')
                through10=through10[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]  
                state=Vissim.Net.SignalControllers.ItemByKey(12).SGs.ItemByKey(1).AttValue('SigState')
                left12=left12[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]
                state=Vissim.Net.SignalControllers.ItemByKey(12).SGs.ItemByKey(6).AttValue('SigState')
                through12=through12[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]   
                state=Vissim.Net.SignalControllers.ItemByKey(13).SGs.ItemByKey(1).AttValue('SigState')
                left13=left13[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]
                state=Vissim.Net.SignalControllers.ItemByKey(13).SGs.ItemByKey(6).AttValue('SigState')
                through13=through13[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]  
                state=Vissim.Net.SignalControllers.ItemByKey(15).SGs.ItemByKey(6).AttValue('SigState')
                through15=through15[1:]+[1 if state=='GREEN' else (0 if state=='RED' else 2)]   
                state=Vissim.Net.SignalControllers.ItemByKey(16).SGs.ItemByKey(6).AttValue('SigState')                                                                                  
                                                   
            if i==intro_630:
                new_Vehicle=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, 38, 1, 0, 53, True)
                dist=1380

            if i>intro_630 and np.prod(flag)==0:
                dist+=0.146666667*float(new_Vehicle.AttValue('Speed'))  
                k=0
                if flag[k]==0 and i%10==0:
                    preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10+23.5, dist]+det10+det12+left10+through10+left12+through12]))[0]
                    if preempt>0.94 or dist>=sig_location[k]-(76.266666667*12.0):
                        new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                        print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-12 @', i/10, ': Preempt Probability:', preempt)
                        preemptnow[k]=1
                        flag[k]=1

                k=1
                if flag[k]==0 and i%10==0:
                    preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10+23.5, dist]+det10+det12+preempt12+det13+left10+through10+left12+through12+left13+through13]))[0]
                    if preempt>0.95 or dist>=sig_location[k]-(76.266666667*12.0):
                        new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                        print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-13 @', i/10, ': Preempt Probability:', preempt)
                        preemptnow[k]=1
                        flag[k]=1 

                k=2
                if flag[k]==0 and i%10==0:
                    preempt=loaded_models[k].predict(np.array([[(i-intro_630)/10+23.5, dist]+det12+preempt12+det13+preempt13+det15+left12+through12+left13+through13+through15]))[0]
                    if preempt>0.925 or dist>=sig_location[k]-(76.266666667*12.0):
                        new_Vehicle_dummy=Vissim.Net.Vehicles.AddVehicleAtLinkPosition(630, ERV_links[k], 1, 0, 80, True)
                        print('SimNum:', simnum, ':RBC Normal Preemption: Preempt-15 @', i/10, ': Preempt Probability:', preempt)
                        flag[k]=1                         
                                                                                                                
        print('\n')
        Vissim.Simulation.Stop()


