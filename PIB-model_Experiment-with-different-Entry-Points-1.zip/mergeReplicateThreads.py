import os

rep_size=[10, 11, 11]

filextent=[]
k=1
last_extent=0

for item in rep_size:
    new_extent=last_extent+item
    filextent.append([k, last_extent+1, new_extent])
    k+=1; last_extent=new_extent

if not os.path.isdir('OutFiles'):
    os.makedirs('OutFiles') 

if not os.path.isdir('2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE.results'):
    os.makedirs('2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE.results')     
  

for item in filextent:
    fileloc='./run_'+str(item[0])+'/OutFiles/'
    filelist=os.listdir(fileloc)

    for file in filelist:
        f=file.split('.')
        init_num=int(f[0][-3:])
        Source=fileloc+file
        Destination='./OutFiles/'+f[0][:-3]+str(999+item[1]+init_num)[1:]+'.'+f[1]
        print(Source, Destination)
        os.rename(Source, Destination)

    fileloc='./run_'+str(item[0])+'/'
    filelist=os.listdir(fileloc)

    for file in filelist:
        if len(file.split('.err'))==2:
            f=file.split('.')
            try:
            	init_num=int(f[0][-3:])
            except ValueError:
            	continue
            Source=fileloc+file
            Destination='./'+f[0][:-3]+str(999+item[1]+init_num)[1:]+'.'+f[1]
            print(Source, Destination)
            os.rename(Source, Destination)
        elif len(file.split('.results'))==2:
            fileloc1=fileloc+file+'/'
            filelist1=os.listdir(fileloc1)
            for file1 in filelist1:
                db_int=int(file1[:-3])
                Source=fileloc1+file1
                Destination='./'+file+'/'+str(db_int+item[1]-1)+'.db'
                print(Source, Destination)
                os.rename(Source, Destination)              