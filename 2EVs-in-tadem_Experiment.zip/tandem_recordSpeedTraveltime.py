import csv
from bisect import bisect

scenarios=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        f=int(line.split('\n')[0])
        scenarios.append(str(f+1000)[1:])

gaps=['10s', '40s', '80s', '90s', '100s', '110s', '120s', '160s', '200s', '240s', '280s', '320s', '480s', '640s', '800s', '960s']

Data=[['simNum']]
for item in gaps:
    Data[0]+=[item+'_TT', item+'_Speed']
threadnum=1000
for simNum in scenarios:
    print(simNum)
    data=[simNum]+[0 for _ in Data[0][1:]]
    threadnum+=1

    for i in range(int((len(Data[0])-1)/2)):
        VNs=[]
        travStart=[0, 0]
        travEnd=[0, 0]
        preempt=Data[0][2*i+1][:-3]
        fname=f'./{preempt}/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{str(threadnum)[1:]}.rsr'
        with open(fname) as infile:
            for inline in infile:
                g=inline.split('\n')[0].split(';')
                try:
                    No, vN, vtype=int(g[1]), int(g[2]), int(g[3])
                    if No==27 and vtype==630:
                        VNs.append(vN)
                except (ValueError, IndexError):
                    continue

        with open(fname) as infile:
            for inline in infile:
                g=inline.split('\n')[0].split(';')
                try:
                    t, No, vN, vtype, trav=float(g[0]), int(g[1]), int(g[2]), int(g[3]), float(g[4])
                    if No in [30, 49] and vtype==630:
                        j=VNs.index(vN)
                        if No==30:
                            travStart[j]=t-trav
                        else:
                            travEnd[j]=t
                except (ValueError, IndexError):
                    continue                    

        trav1, trav2=travEnd[0]-travStart[0], travEnd[1]-travStart[1]
        speed1, speed2=(23942.5-3570)*0.68181818/trav1, (23942.5-3570)*0.68181818/trav2
        data[2*i+1]=f'{trav1}_{trav2}'
        data[2*i+2]=f'{speed1}_{speed2}'             

    Data.append(data)

with open('2022-09-22_Speed-Traveltime-Summary_EV-Tandem.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   