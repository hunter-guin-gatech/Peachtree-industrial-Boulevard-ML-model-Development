from matplotlib import pyplot as plt 
import numpy as np 
from scipy.stats import ks_2samp, ttest_ind
import pandas as pd
import seaborn as sns

def adjustFigAspect(fig,aspect=1):
    '''
    Adjust the subplot parameters so that the figure has the correct
    aspect ratio.
    '''
    xsize,ysize = fig.get_size_inches()
    minsize = min(xsize,ysize)
    xlim = .4*minsize/xsize
    ylim = .4*minsize/ysize
    if aspect < 1:
        xlim *= aspect
    else:
        ylim /= aspect
    fig.subplots_adjust(left=.5-xlim,
                        right=.5+xlim,
                        bottom=.5-ylim,
                        top=.5+ylim)


gaps=['10s', '40s', '80s', '90s', '100s', '110s', '120s', '160s', '200s', '240s', '280s', '320s', '480s', '640s', '800s', '960s']

def BoxplotFormat(list2D):
    maxlen=0
    for l in list2D:
        maxlen=max(maxlen, len(l))
    for i in range(len(list2D)):
        l=len(list2D[i])
        for j in range(l, maxlen):
            list2D[i].append(np.NaN)
    return np.array(list(map(list, zip(*list2D))))

travelTime=[[]]
speed=[[]]
for i in range(len(gaps)):
	travelTime+=[[], []]
	speed+=[[], []]

outfile='2022-09-22_Speed-Traveltime-Summary_EV-Tandem.csv'
n=0
with open(outfile) as file:
	for line in file:
		n+=1
		if n>1:
			f=line.split('\n')[0].split(',')
			for i in range(len(gaps)):
				trav1, trav2=[float(j) for j in f[2*i+1].split('_')]
				speed1, speed2=[float(j) for j in f[2*i+2].split('_')]
				travelTime[2*i+1].append(trav1)
				travelTime[2*i+2].append(trav2)
				speed[2*i+1].append(speed1)
				speed[2*i+2].append(speed2)

outfile=f'../model-analysis/2022-08-15_Speed-Traveltime-Summary_20NB_System.csv'
n=0
with open(outfile) as file:
	for line in file:
		n+=1
		if n>1:
			f=line.split('\n')[0].split(',')
			travelTime[0].append(float(f[9]))
			speed[0].append(float(f[10]))												

columns=['Base-Expt', 'Leading ERV', 'Following ERV']
for i in range(len(gaps)-1):
	columns+=[f'Leading ERV_{i+1}', f'Following ERV_{i+1}']

colors=['cyan']+['lawngreen', 'yellow']*len(gaps)

# Speed plot

fig = plt.figure()
adjustFigAspect(fig,aspect=3)
Data=BoxplotFormat(speed)
df = pd.DataFrame(data = Data, columns = columns)
sns.boxplot(x="variable", y="value", data=pd.melt(df), palette=colors, width=0.5, linewidth=0.3, fliersize=2)
means=[np.nanmean(dat) for dat in Data.T]
plt.scatter(columns, means, c='r', s=7)
plt.xlabel('Experimental Setups [Gap between EVs in tandem]', fontsize=7)
plt.ylabel('Speed [mph]', fontsize=8)
plt.title(f'System 12NB to 20NB: Speed Boxplot\nExperiments with ERVs in Tandem', fontsize=9)
plt.ylim([32, 50])
plt.xlim([-0.5, 1+2*len(gaps)])
plt.grid(axis='y', color = 'c', linestyle = '--', linewidth = 0.1)
for l in range(3):
	plt.plot([], [], label=columns[l], linewidth=5, color=colors[l])
plt.legend(fontsize=5, ncol=3, bbox_to_anchor=(0.8, -0.33))  
plt.plot([.5, .5], [32, 50], color='black')
for l in range(len(gaps)-1):
	plt.plot([2.5+2*l, 2.5+2*l], [32, 50], linewidth=1, linestyle='--', color='black')
plt.xticks([0]+[1.5+2*l for l in range(len(gaps))], ['Base']+gaps, size=5, rotation=90)
plt.yticks(range(32, 51, 2), range(32, 51, 2), size=6)
plt.savefig(f'2022-09-22-Speed-BoxPlot_Tamdem.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close() 


#Travel time

fig = plt.figure()
adjustFigAspect(fig,aspect=3)
Data=BoxplotFormat(travelTime)
df = pd.DataFrame(data = Data, columns = columns)
sns.boxplot(x="variable", y="value", data=pd.melt(df), palette=colors, width=0.5, linewidth=0.3, fliersize=2)
means=[np.nanmean(dat) for dat in Data.T]
plt.scatter(columns, means, c='r', s=7)
plt.xlabel('Experimental Setups [Gap between EVs in tandem]', fontsize=7)
plt.ylabel('TravelTime [s]', fontsize=7)
plt.title(f'System 12NB to 20NB: Travel-time Boxplot\nExperiments with ERVs in Tandem', fontsize=9)
minmax=[np.nanmin(Data), np.nanmax(Data)]
range1=minmax[1]-minmax[0]
plt.ylim([minmax[0]-range1*0.05,  minmax[1]+range1*0.05])
plt.xlim([-0.5, 1+2*len(gaps)])
plt.grid(axis='y', color = 'c', linestyle = '--', linewidth = 0.1)
for l in range(3):
	plt.plot([], [], label=columns[l], linewidth=5, color=colors[l])
plt.legend(fontsize=5, ncol=3, bbox_to_anchor=(0.8, -0.33))  
plt.plot([.5, .5], [minmax[0]-range1*0.05,  minmax[1]+range1*0.05], color='black')
for l in range(len(gaps)-1):
	plt.plot([2.5+2*l, 2.5+2*l], [minmax[0]-range1*0.05,  minmax[1]+range1*0.05], linewidth=1, linestyle='--', color='black')
plt.xticks([0]+[1.5+2*l for l in range(len(gaps))], ['Base']+gaps, size=5, rotation=90)
plt.yticks(size=6)
plt.savefig(f'2022-09-22-TravelTime-BoxPlot_Tamdem.png', bbox_inches='tight', dpi=600) 
plt.clf()     
plt.close() 
