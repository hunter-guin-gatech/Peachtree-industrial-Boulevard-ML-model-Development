from bisect import bisect
import os
import matplotlib.pyplot as plt 
import numpy as np

def sig2col(x):
    if x=='amber':
        return 'yellow'
    else:
        return x

        
if not os.path.isdir('./plots20NB'):
    os.makedirs('./plots20NB')  

intersections=[10, 12, 13, 15, 16, 18, 19, 20]

intersectionName=['MedLock Br Rd', 'S.Old Peachtree Rd', 'Highwoods Center', 'Pickneyville Park', 'S.Berkeley Lk Rd', 'N.Berkeley Lk Rd', 'Summit Ridge Pkwy', 'Howell Ferry Rd']

signalLoc=[3419, 8094, 9312.5, 10974, 11916, 18506, 19214.5, 23942.5]

test_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
        test_nums.append(int(line.split('\n')[0]))

designs={}
gaps=['90s', '100s', '110s', '800s', '960s']
for item in gaps:
    designs[item]=item 

for i in range(5, 32):
    for design in list(designs.keys()):
        seed=1000+test_nums[i]
        threadnum=str(1001+i)[1:]
        simNum=str(1000+test_nums[i])[1:]
        rs=int((seed-1001)/32)+1
        itr=(seed-1001)%32+101
        print('Design:', design, 'runNum:', seed-1000, 'random seed:', rs, 'runNo:', itr-100)

        ERVs=[]

        fname=f'./{design}/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{threadnum}.rsr'
        with open(fname) as infile:
            for inline in infile:
                g=inline.split('\n')[0].split(';')
                try:
                    No, vN, vtype=int(g[1]), int(g[2]), int(g[3])
                    if No==27 and vtype==630:
                        ERVs.append(vN)
                except (ValueError, IndexError):
                    continue        

        tmin=99999; tmax=0
        xmin=99999; xmax=0

        n=0
        Vn=-1

        with open(f'./trajdata20NB/2022-09-22_PIB-RBC-Preempt-Trajectory_{simNum}_{design}.csv') as file:
            for line in file:        
                n+=1
                if n>1:
                    f=line.split('\n')[0].split(',')               
                    vcode, t, x, vtype, turn=f[0], float(f[1]), float(f[2]), int(f[3]), int(f[4])   
                    vn, seg=[int(item) for item in vcode.split('_')]
                    if Vn!=vn:
                        if Vn!=-1:
                            if prevvtype!=630:
                                if prevturn==1:
                                    plt.plot(T, X, lw=0.1, color='dimgray')
                                elif prevturn==2:
                                    plt.plot(T, X, lw=0.1, color='dimgray', linestyle='--')
                                else:
                                    plt.plot(T, X, lw=0.1, color='dimgray', linestyle='-.')
                            else:
                                if Vn==ERVs[0]:
                                    plt.plot(T, X, lw=0.5, color='blue')
                                else:
                                    plt.plot(T, X, lw=0.5, color='purple')

                        X=[]; T=[]
                        Vn=vn

                    X.append(x); T.append(t)
                    tmin=min(t, tmin); tmax=max(t, tmax)
                    xmin=min(x, xmin); xmax=max(x, xmax)  
                    prevvtype, prevturn=vtype, turn                       

        if vtype!=630:
            if turn==1:
                plt.plot(T, X, lw=0.1, color='dimgray')
            elif turn==2:
                plt.plot(T, X, lw=0.1, color='dimgray', linestyle='--')
            else:
                plt.plot(T, X, lw=0.1, color='dimgray', linestyle='-.')
        else:
            plt.plot(T, X, lw=0.5, color='blue')

        sigdata=[]
        for item in intersections:
            sigdata.append([[0], ['red']])      
        
        with open(f'./{design}/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{threadnum}.lsa') as file:
            for line in file:
                f=line.split(';')
                try:
                    t, ph, state=int(float(f[0])), str(int(f[2]))+'-'+str(int(f[3])), ''.join(f[4].split())
                    j=0
                    for item in intersections:
                        if ph==str(item)+'-6':
                            st=int(sigdata[j][0][-1])+1; st_st=sigdata[j][1][-1]
                            for t1 in range(st, t):
                                sigdata[j][0].append(t1); sigdata[j][1].append(st_st)
                            sigdata[j][0].append(t); sigdata[j][1].append(state) 
                            break                         
                        j+=1           
                except (ValueError, IndexError):
                    continue

        for j in range(len(intersections)): 
            for k in range(len(sigdata[j][0])):
                t=sigdata[j][0][k]
                if t>=tmin and t<=tmax:
                    plt.scatter([t], [signalLoc[j]], s=1, color=sig2col(sigdata[j][1][k]))  

        tmin=int(round(tmin/160)*160)
        tmax=int(round(tmax/160)*160+160)
        time_ticks=list(range(tmin, tmax+1, 160))

        for j in range(len(intersections)): 
            with open(f'./{design}/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{intersections[j]}_{threadnum}.ldp') as file:
                for line in file:
                    f=line.split('\n')[0].split()
                    try:
                        t=float(f[0].split('.0')[0]); ap=int(f[3])
                        if ap!=0:
                            plt.scatter([t], [signalLoc[j]+200], s=2, color='pink')
                    except (ValueError, IndexError):
                        continue 
            plt.text(tmax, signalLoc[j]+200, intersectionName[j], fontsize=6.5, fontweight='bold', ha='right', color='#A15589')    

        plt.xticks(time_ticks, rotation=45)
        plt.grid(axis='x', color = 'c', linestyle = '--', linewidth = 0.05)
        plt.title('Random Seed: '+str(rs)+'; RunNo: '+str(itr)[1:]+f'; System: 12NB to 20NB\nIn tandem: Lag: {designs[design]}: Trajectory of Vehicles around ERVs')
        plt.xlabel('Time[s] ')
        plt.ylabel('Distance[ft]')    
        plt.savefig(f'./plots20NB/2022-09-22_{rs}_{str(itr)[1:]}_Trajectory_Tandem_{design}.png', bbox_inches='tight', dpi=1200)        
        plt.clf()
        plt.close()

   