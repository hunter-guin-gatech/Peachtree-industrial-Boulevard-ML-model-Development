import csv
from bisect import bisect

allowed_nums=[]
with open('../testing_run-num.txt') as file:
    for line in file:
    	f=str(int(line.split('\n')[0])+1000)[1:]
    	allowed_nums.append(f)

intersections=[18, 19, 20]
thread=1000
designs=['CICO', 'Base', 'Predicted']

Data=[['simNum', 'CI-CO_Dur', 'Base_Dur', 'Predicted-Dur']]

for simNum in allowed_nums:
    thread+=1
    print(simNum)
    data=[simNum, 0, 0, 0]
    threadnum=str(1000+thread)[1:]

    for intr in intersections:
        k=1
        for design in designs:
            fname=f'./{design}/OutFiles/2022-05-09_CTEDD_Peachtree-Industrial-Blvd-RBC-P_NE_{intr}_{threadnum}.ldp'
            with open(fname) as file:
                for line in file:
                    f=line.split('\n')[0].split()
                    try:
                        ap=int(f[3])
                        data[k]+=int(ap!=0)
                    except (ValueError, IndexError):
                        continue 
            k+=1                                                           

    Data.append(data)

with open('2022-08-15_Preempt-Duration-Summary_Diff-Entry-2.csv', "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(Data)


   